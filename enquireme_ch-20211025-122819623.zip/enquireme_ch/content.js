document.addEventListener('mouseup',function(event)
{
    var sel = window.getSelection().toString();
    if(sel.length)
	{
		chrome.runtime.sendMessage({command : "setText",action : sel});
	}
})