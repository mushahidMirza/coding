function PopupCenter(url, title, w, h) {
    // Fixes dual-screen position                         Most browsers      Firefox
    var dualScreenLeft = window.screenLeft != undefined ? window.screenLeft : window.screenX;
    var dualScreenTop = window.screenTop != undefined ? window.screenTop : window.screenY;

    var width = window.innerWidth ? window.innerWidth : document.documentElement.clientWidth ? document.documentElement.clientWidth : screen.width;
    var height = window.innerHeight ? window.innerHeight : document.documentElement.clientHeight ? document.documentElement.clientHeight : screen.height;

    var systemZoom = width / window.screen.availWidth;
var left = (width - w) / 2 / systemZoom + dualScreenLeft
var top = (height - h) / 2 / systemZoom + dualScreenTop
    var newWindow = window.open(url, title, 'scrollbars=yes, width=' + w / systemZoom + ', height=' + h / systemZoom + ', top=' + top + ', left=' + left);

    // Puts focus on the newWindow
    if (window.focus) newWindow.focus();
}

var seltext = null;

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse)
{
    switch(request.command)
    {
        case 'setText':
            window.seltext = request.action
			return false;
        break;

        default:
            sendResponse({rsp:"wasSet"});
			return false;
        break;
    }
});

chrome.contextMenus.create({
    id: "mouser-enquire",
    title: 'I Wish for Price for "%s" - Ctrl+Z',
    contexts: ["all"]
});

chrome.commands.onCommand.addListener(function(command) {
		var searchstring = window.seltext;
		PopupCenter("http://yourpartgenie.com/login/index/"+searchstring,'Send Enquiry','900','700');  
});

chrome.contextMenus.onClicked.addListener(function(info, tab) {
    if (info.menuItemId == "mouser-enquire") {
        //console.log("yay!");
		var searchstring = info.selectionText;
		PopupCenter("http://yourpartgenie.com/login/index/"+searchstring,'Send Enquiry','900','700');  

    }
});